package com.LuisSolarte.myapplication.controller;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.LuisSolarte.myapplication.R;

public class MenuApp extends AppCompatActivity {
    Button btnColores;
    Button btnFrutas;
    Button btnAnimales;
    Button btnNumeros;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_app);

        btnFrutas = findViewById(R.id.btnFrutas);
        btnFrutas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent irFrutas = new Intent(MenuApp.this, Frutas.class);
                startActivity(irFrutas);
            }
        });

        btnAnimales = findViewById(R.id.btnAnimales);
        btnAnimales.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent irAnimales = new Intent(MenuApp.this, Animales.class);
                startActivity(irAnimales);
            }
        });

        btnNumeros = findViewById(R.id.btnNumeros);
        btnNumeros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent irNumeros = new Intent(MenuApp.this, Numeros.class);
                startActivity(irNumeros);
            }
        });

        btnColores = findViewById(R.id.btnColores);
        btnColores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent irColores = new Intent(MenuApp.this, Colores.class);
                startActivity(irColores);
            }
        });
    }
}