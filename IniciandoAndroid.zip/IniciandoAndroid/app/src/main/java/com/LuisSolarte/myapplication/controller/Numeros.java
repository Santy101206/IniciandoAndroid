package com.LuisSolarte.myapplication.controller;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.LuisSolarte.myapplication.R;

public class Numeros extends AppCompatActivity {

    ImageView imguno;
    ImageView imgdos;
    ImageView imgtres;
    TextView textuno;
    TextView textdos;
    TextView texttres;
    MediaPlayer uno;
    MediaPlayer dos;
    MediaPlayer tres;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numeros);

        textuno = findViewById(R.id.textuno);
        imguno = findViewById(R.id.imguno);

        textdos = findViewById(R.id.textdos);
        imgdos = findViewById(R.id.imgdos);

        texttres = findViewById(R.id.texttres);
        imgtres = findViewById(R.id.imgtres);

        imguno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                uno = MediaPlayer.create(Numeros.this,R.raw.uno);
                uno.start();
                textuno.setText("One");
            }
        });
        imgdos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dos = MediaPlayer.create(Numeros.this,R.raw.dos);
                dos.start();
                textdos.setText("Two");
            }
        });
        imgtres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tres = MediaPlayer.create(Numeros.this,R.raw.tres);
                tres.start();
                texttres.setText("Three");
            }
        });
    }
}