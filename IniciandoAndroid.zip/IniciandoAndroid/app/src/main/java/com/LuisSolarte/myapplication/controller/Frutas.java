package com.LuisSolarte.myapplication.controller;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.LuisSolarte.myapplication.R;

public class Frutas extends AppCompatActivity {

    ImageView Manzana;
    ImageView Sandia;
    ImageView Maracu;
    TextView textmanzana;
    TextView textmaracu;
    TextView textsandia;

    MediaPlayer apple;
    MediaPlayer maracu;
    MediaPlayer sandi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_frutas);

        textmanzana = findViewById(R.id.textmanzana);
        Manzana = findViewById(R.id.imgmanzana);

        textmaracu = findViewById(R.id.textmaracu);
        Maracu = findViewById(R.id.imgmaracu);

        textsandia = findViewById(R.id.textsandia);
        Sandia = findViewById(R.id.imgsandia);

        Manzana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                apple = MediaPlayer.create(Frutas.this,R.raw.apple);
                apple.start();
                textmanzana.setText("Apple");
            }
        });

        Maracu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                maracu = MediaPlayer.create(Frutas.this,R.raw.maracu);
                maracu.start();
                textmaracu.setText("Passion Fruit");
            }
        });
        Sandia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sandi = MediaPlayer.create(Frutas.this,R.raw.sandi);
                sandi.start();
                textsandia.setText("Watermelon");
            }
        });

    }
}