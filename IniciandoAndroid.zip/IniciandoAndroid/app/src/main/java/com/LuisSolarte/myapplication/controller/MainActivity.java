package com.LuisSolarte.myapplication.controller;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.LuisSolarte.myapplication.R;

public class MainActivity extends AppCompatActivity {
    Button btnSiguiente;// Declaro el elemento a programar

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSiguiente = findViewById(R.id.btnSiguiente);
        btnSiguiente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent irsiguiente = new Intent(MainActivity.this, MenuApp.class);
                startActivity(irsiguiente);

                Toast.makeText(MainActivity.this, "Presionaste Clic", Toast.LENGTH_SHORT).show();
            }
        });

    }
}