package com.LuisSolarte.myapplication.controller;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.LuisSolarte.myapplication.R;

public class Animales extends AppCompatActivity {

    ImageView imgerizo;
    ImageView imggallina;
    ImageView imgmedusa;
    TextView texterizo;
    TextView textgallina;
    TextView textmedusa;
    MediaPlayer eri;
    MediaPlayer galli;
    MediaPlayer medu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_animales);

        texterizo = findViewById(R.id.texterizo);
        imgerizo = findViewById(R.id.imgerizo);

        textgallina = findViewById(R.id.textgallina);
        imggallina = findViewById(R.id.imggallina);

        textmedusa = findViewById(R.id.textmedusa);
        imgmedusa = findViewById(R.id.imgmedusa);

        imgerizo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eri = MediaPlayer.create(Animales.this,R.raw.eri);
                eri.start();
                    texterizo.setText("Hedgehog");
            }
        });

        imggallina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                galli = MediaPlayer.create(Animales.this,R.raw.galli);
                galli.start();
                textgallina.setText("Hen");
            }
        });
        imgmedusa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                medu = MediaPlayer.create(Animales.this,R.raw.medu);
                medu.start();
                textmedusa.setText("Jellyfish");
            }
        });

    }
}