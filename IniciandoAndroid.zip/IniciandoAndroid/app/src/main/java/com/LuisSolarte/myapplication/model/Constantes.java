package com.LuisSolarte.myapplication.model;

public class Constantes {

    //Creacion de constantes
    public static String NAME_DATABASE = "Registros";
    public  static int VERSION_DB = 1;


    public static String SENTENCIATABLA = "CREATE TABLE DATOS(nombre text, apellido text, eddad int, correo text, nickname text)";
    public static String SENTENCIATABLA2 = "CREATE TABLE TARJETAS(tipo text, numero int, cvc int)";

}
