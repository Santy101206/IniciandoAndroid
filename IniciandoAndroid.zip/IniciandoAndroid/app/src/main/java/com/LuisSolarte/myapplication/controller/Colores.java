package com.LuisSolarte.myapplication.controller;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.LuisSolarte.myapplication.R;

public class Colores extends AppCompatActivity {
    ImageView yellow;
    ImageView red;
    ImageView blue;
    TextView textamarillo;
    TextView textrojo;
    TextView textazul;
    MediaPlayer SoundYellow;
    MediaPlayer SoundRed;
    MediaPlayer SoundBlue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_colores);

        textamarillo = findViewById(R.id.textamarillo);
        yellow = findViewById(R.id.yellow);

        textrojo = findViewById(R.id.textrojo);
        red = findViewById(R.id.red);

        textazul = findViewById(R.id.textazul);
        blue = findViewById(R.id.blue);

        yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                SoundYellow = MediaPlayer.create(Colores.this,R.raw.yellowsound);
                SoundYellow.start();
                textamarillo.setText("Yellow");
            }
        });

        red.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                SoundRed = MediaPlayer.create(Colores.this,R.raw.red);
                SoundRed.start();

                textrojo.setText("Red");
                    }
        });
        blue.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {

                                SoundBlue = MediaPlayer.create(Colores.this,R.raw.blue);
                SoundBlue.start();



                textazul.setText("Blue");
            }
        });


    }
}