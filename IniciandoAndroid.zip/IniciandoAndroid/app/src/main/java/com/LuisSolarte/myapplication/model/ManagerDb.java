package com.LuisSolarte.myapplication.model;

public class ManagerDb {
}
