package com.LuisSolarte.myapplication.controller;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.LuisSolarte.myapplication.R;
import com.LuisSolarte.myapplication.model.ConexionHelper;
import com.LuisSolarte.myapplication.model.Datos;


public class interfazdatos extends AppCompatActivity {

        EditText btnNombre, btnApellido, btnCorreo, btnEdad, btnNickname;
        Button btnRegistro;
        String nombre, apellido, correo, nickname;
        int edad;

        ConexionHelper conexionHelper;
        SQLiteDatabase db;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_registro_datos);


            //Conexion de base de datos
             conexionHelper = new ConexionHelper(interfazdatos.this);
             db = conexionHelper.getWritableDatabase();// Se abre la base de datos en modo escritura
            Toast.makeText(this,"Base de datos creada", Toast.LENGTH_SHORT).show();

             //Demas datos

            btnNombre = findViewById(R.id.btnNombre);
            btnApellido = findViewById(R.id.btnApellido);
            btnEdad = findViewById(R.id.btnEdad);
            btnCorreo = findViewById(R.id.btnCorreo);
            btnNickname = findViewById(R.id.btnNickname);
            btnRegistro = findViewById(R.id.btnRegistro);

            btnRegistro.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    nombre = btnNombre.getText().toString();
                    apellido = btnApellido.getText().toString();
                    correo = btnCorreo.getText().toString();
                    nickname = btnNickname.getText().toString();
                    edad = Integer.parseInt(btnEdad.getText().toString());

                    Datos datos = new Datos(nombre, apellido, edad, correo, nickname);
                    Toast.makeText(interfazdatos.this, "Los datos son: "+ datos.toString(), Toast.LENGTH_SHORT).show();
                }
            });


        }
    }
